import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PathServiceService } from '../path-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators,PatternValidator } from '@angular/forms';
import { LocalStorage } from '@ngx-pwa/local-storage';
import * as $ from 'jquery';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router, private localStorage:LocalStorage, private http:HttpClient,public webservicesURL:PathServiceService ){}

  serviceURL =  this.webservicesURL.webServicePath;

  loggedInuser:any;
  loginForm:any;
  regForm:any;
  loginStatus:any;
  isLogin = true;

  ngOnInit() {
    this.localStorage.getItem('logged').subscribe((User) => {
      if (User) {
        this.loggedInuser = User._id;
      }
    });

    this.createLoginForm();
    this.createRegForm();
  }

  createLoginForm() {
    this.loginForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    })
  }

  createRegForm() {
    this.regForm = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.pattern('^[a-zA-Z ]+$')]),
      email: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
      cpassword: new FormControl('', [Validators.required, Validators.minLength(6)]),
    })
  }

  ChangeForm(sts){
    this.isLogin = sts;
  }

  public login() {
    // this.spinnerService.show();
    this.http.post(this.serviceURL + '/userapi/login', this.loginForm.value)
      .subscribe(res => {
        this.loginStatus = res;
        if (this.loginStatus.status == 0) {
          $('#alertd').html('Invalid username and password');
          $('#alertd').css('display', 'block');
          setTimeout(() => {
            $('#alertd').css('display', 'none');
          }, 3000);
        } else {
          this.loginForm.markAsPristine();
          this.loginForm.reset();
          this.webservicesURL.userLogged(this.loginStatus.user);
          this.router.navigateByUrl('/userlist');
          this.localStorage.setItem('logged', this.loginStatus.user).subscribe(() => { });
        }
      }, (err) => {
        console.log(err);
      }
      );
  }

  addUser(){
    if(this.regForm.value.password == this.regForm.value.cpassword){
      this.http.post(this.serviceURL + '/userapi/adduser', this.regForm.value)
      .subscribe(res=>{
        if(res == 0){
          $('#alertd').html('Email already exist');
          $('#alertd').css('display', 'block');
          setTimeout(() => {
            $('#alertd').css('display', 'none');
          }, 3000);
        }
        else{
          $('#alerts').html('Registration Successful');
          $('#alerts').css('display', 'block');
          setTimeout(() => {
            $('#alerts').css('display', 'none');
          }, 3000);
          this.regForm.reset();
          this.regForm.markAsPristine();
        }
        
      },(err)=>{  
        console.log(err);
      })
    }else{
      $('#alertd').html('Password Does not match');
          $('#alertd').css('display', 'block');
          setTimeout(() => {
            $('#alertd').css('display', 'none');
          }, 3000);
    }
  }

}
