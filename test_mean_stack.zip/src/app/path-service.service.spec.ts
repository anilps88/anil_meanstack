import { TestBed, inject } from '@angular/core/testing';

import { PathServiceService } from './path-service.service';

describe('PathServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PathServiceService]
    });
  });

  it('should be created', inject([PathServiceService], (service: PathServiceService) => {
    expect(service).toBeTruthy();
  }));
});
