import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { LoginComponent } from './login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core/src/metadata/ng_module';
import { AppComponent } from './app.component';
import { EmployeesComponent } from './employees/employees.component';
import { UserlistComponent } from './userlist/userlist.component';
import { CreateuserComponent } from './createuser/createuser.component';

export const AppRoutes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: 'employees', component: EmployeesComponent },
    { path: 'userlist', component: UserlistComponent },
    { path: 'createuser', component: CreateuserComponent },
    { path: 'edit-employee/:id', component: EditEmployeeComponent },
    { path: 'edit-user/:id', component: EditUserComponent },
    { path: '', redirectTo: 'login', pathMatch: 'full'}
];
 
export const ROUTING: ModuleWithProviders = RouterModule.forRoot(AppRoutes);