import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PathServiceService } from '../path-service.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormControl, Validators,PatternValidator } from '@angular/forms';
import { LocalStorage } from '@ngx-pwa/local-storage';
import * as $ from 'jquery';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {

  constructor(private router:Router, private localStorage:LocalStorage, private http:HttpClient,public webservicesURL:PathServiceService ){}

  serviceURL =  this.webservicesURL.webServicePath;

  loggedInuser:any;
  usrFrom:any;
  p: number = 1;

  usersList:any;

  ngOnInit() {
    this.localStorage.getItem('logged').subscribe((User)=>{
      if(User){
        this.loggedInuser = User._id;
      }
      else{
        this.router.navigateByUrl('login');
      }
    });

    this.getUsers();
  }
 
 

  getUsers(){
    this.http.get(this.serviceURL + '/usersapi/getAllUsers')
    .subscribe(res=>{
      this.usersList = res;
    },(err)=>{
      console.log(err);
    })
  }

  Delete(id){
    if(confirm('Are you sure to delete record.?')){
      this.http.delete(this.serviceURL + '/usersapi/deleteUsr/'+id)
      .subscribe(res=>{
        $('#alerts').html('Record Deleted');
        $('#alerts').css('display', 'block');
        setTimeout(() => {
          $('#alerts').css('display', 'none');
        }, 3000);
        this.getUsers();
      },(err)=>{
        console.log(err);
      })
    }
  }

    /*  image upload */
    imgUpload(fileInput: any) {
      let image = fileInput.target.files;
  
      const formData: any = new FormData();
      const files: Array<File> = image;
  
      var ext = files[0].name.match(/\.(.+)$/)[1].toLowerCase();
      var size = files[0].size / 1024;
      
      if(size < 2048){
  
        if (ext === 'jpg' || ext === 'jpeg' || ext === 'png') {
  
          formData.append("profile", files[0], files[0]['name']);
          this.http.post(this.serviceURL + '/usersapi/uploadImage', formData)
            .subscribe(res => {
              let profileImage = res['uploadname'];
              if (profileImage) {
                this.usrFrom.patchValue({
                  profile: profileImage
                });
                console.log(this.usrFrom.value)
              }
    
            }, (err) => {
              console.log(err);
            }
            );
        } else {
          $('#alertd').css('display', 'block');
          $('#alertd').html('Please select image .jpeg, .jpg, png');
          setTimeout(() => {
            $('#alertd').css('display', 'none');
          }, 5000);
        }
      }
      else{
        $('#alertd').css('display', 'block');
        $('#alertd').html('File size exeeded (File size must be less than 2 MB)');
          setTimeout(() => {
            $('#alertd').css('display', 'none');
          }, 5000);
      }
    }

}
