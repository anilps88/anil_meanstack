import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { ROUTING } from './app.routing';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LocalStorageModule } from '@ngx-pwa/local-storage';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { PathServiceService } from './path-service.service';
import { EmployeesComponent } from './employees/employees.component';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { CreateuserComponent } from './createuser/createuser.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { UserlistComponent } from './userlist/userlist.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    EmployeesComponent,
    EditEmployeeComponent,
    CreateuserComponent,
    EditUserComponent,
    UserlistComponent
  ],
  imports: [
    BrowserModule,
    ROUTING,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    LocalStorageModule,
    NgxPaginationModule
  ],
  providers: [PathServiceService,{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  bootstrap: [AppComponent]
})
export class AppModule { }
