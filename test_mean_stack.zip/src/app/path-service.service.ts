import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class PathServiceService {

  constructor() { }

  user = new Subject<any>();
  userlogin$ = this.user.asObservable();

  webServicePath:string = '';

  userLogged(data:any){
    if(data){
      this.user.next(data);
    }
  }

}
