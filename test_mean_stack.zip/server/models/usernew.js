const mongoose= require('mongoose');

const UsernewSchema =mongoose.Schema({
	firstname:{
		type:String
	},
	lastname:{
		type:String
	},
	email:{
		type:String
	},
	mobile:{
		type:Number
	}, 
	profile:{
		type:String
	} 
}); 

const Usernew= module.exports = mongoose.model('usernew',UsernewSchema);