const express = require('express');
const router = express.Router();

const mongoose = require('mongoose');

const Usernew = require('../models/usernew.js');

var multer  = require('multer')


router.get('/', function (req, res, next) {
	res.send('yes It worksss..');
});

/* img */

var img = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads/emp-imgs');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + file.originalname);
    }
});

var upload = multer({ storage: img }).single('profile');

router.post('/uploadImage', function (req, res, next) {
    upload(req, res, function (err) {
        if (err) {
            return res.status(501).json({ error: err });
        }
        return res.json({ uploadname: req.file.filename });

    });
});

//fetch all records record 
router.get("/getAllUsers", (req, res, next) => {

	Usernew.find().exec(function (err, emp) {
		res.json(emp);

	});
});

router.post('/adduser', function (req, res, next) {

	Usernew.findOne({ email: req.body.email }).exec(function (err, result) {
		if (result) {
			res.json(0);
		}
		else {
			let date = new Date().toISOString().split('T')[0];

			let newUsernew = new Usernew({
				firstname: req.body.firstname,
				lastname: req.body.lastname,
				email: req.body.email,
				mobile: req.body.mobile, 
				profile: req.body.profile 
			});

			newUsernew.save((err, Admin) => {
				if (err) {
					res.json({ msg: 'Something went wrong' });
				}
				else {

					res.json({ msg: 'Added Sucessfully', 'user': Admin });
				}

			});
		}
	});


});

router.delete('/deleteUsr/:id', function (req, res, next) {
	Usernew.findByIdAndRemove(req.params.id, req.body, function (err, post) {
		if (err) return next(err);
		res.json({ msg: 'Record Deleted', status: 1 });
	});
});

router.get("/getUsernew/:id", (req, res, next) => {

	Usernew.findById(req.params.id, function (err, result) {
		if (result) {
			res.json(result);
		}
		else {
			res.json(0);
		}
	});
});

router.post("/update-user", (req, res, next) => {

	Usernew.findById(req.body.id, function (err, result) {
		if (result) {

				result.firstname = req.body.firstname,
				result.lastname = req.body.lastname,
				result.email = req.body.email,
				result.mobile = req.body.mobile, 
				result.profile = req.body.profile,

				// Save the updated document back to the database
				result.save(function (err, result) {
					if (err) {
						res.json({ msg: 'Something went wrong', status: 0 });
					}
					res.json({ msg: 'Information Updated Sucessfully', status: 1 });
				});

		}
		else {
			res.status(500).send(err);
		}
	});
});


module.exports = router;